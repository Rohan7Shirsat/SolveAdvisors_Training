﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Generic;

namespace Generic
{
    internal class DriverClass
    {
        public static void Main(string[] args)
        {
            
            Demo<string> genrics = new Demo<string>();
            genrics.s = "7777";

            int number = int.Parse(genrics.s);
            Console.WriteLine(number);

            genrics.s = "2022-07-07";

            DateTime date = DateTime.Parse(genrics.s); ;
            Console.WriteLine(date);

        }
    }
}