﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extension
{
	public class Driver
	{
		public static void Main(string[] args)
		{
			string str = "Rohan";

			Console.WriteLine("Reversing a string:" + str.Reverse());
			Console.WriteLine("First letter in upper case:" + str.ChangeUpperCase());
			Console.WriteLine("First letter in lower case:" + str.ChangeLowerCase());
		}
	}
}
